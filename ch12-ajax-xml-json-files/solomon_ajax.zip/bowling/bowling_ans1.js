window.onload = function() 
{
	new Ajax.Request(
		"bowling.php",
		{
			method: "GET",
			onSuccess: ajaxSuccess
		}
	);
};

function ajaxSuccess(ajax)
{
	var bowler = ajax.responseXML.getElementsByTagName("bowler");
	for (var i = 0; i < bowler.length; i++)
	{
		var name = bowler[i].getAttribute("name");
		var th = document.createElement("th");
		th.innerHTML = name;
		$("scores").appendChild(th);
	}
}