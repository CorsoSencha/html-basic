window.onload = function() 
{
	new Ajax.Request(
		"grades.php",
		{
			method: "GET",
			onSuccess: ajaxSuccess
		}
	);
};

function ajaxSuccess(ajax)
{
	var student = ajax.responseXML.getElementsByTagName("student");
	for (var i = 0; i < student.length; i++)
	{
		var studentid = student[i].getAttribute("id");
		var option = document.createElement("option");
		option.innerHTML = studentid;
		$("studentlist").appendChild(option);
	}
}